export default class HospitalizationCommittee {
    constructor(id, committee_head, committee_members){
        this.id = id
        this.committee_head = committee_head
        this.committee_members = committee_members
    }
}
