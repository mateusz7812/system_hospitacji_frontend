import React from 'react';
const HospitalizationsPage = () => {
    return (
        <div>hospitalizations page</div>
    );
}

export default HospitalizationsPage;
