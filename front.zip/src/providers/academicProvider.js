import React from 'react';

export const AcademicContext = React.createContext({});
export const AcademicProvider = AcademicContext.Provider;