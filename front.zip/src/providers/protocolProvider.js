import React from 'react';

export const ProtocolContext = React.createContext({});
export const ProtocolProvider = ProtocolContext.Provider;