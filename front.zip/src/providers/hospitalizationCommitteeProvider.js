import React from 'react';

export const HospitalizationCommitteeContext = React.createContext({});
export const HospitalizationCommitteeProvider = HospitalizationCommitteeContext.Provider;