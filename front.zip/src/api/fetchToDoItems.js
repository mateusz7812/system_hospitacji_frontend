
export const fetchTodoItems = () => {
    //Asynchronous api call
    return new Promise((resolve) => {
        setTimeout(resolve([]), 200);
    });
}

