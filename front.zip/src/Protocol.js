export default class Protocol {
    constructor(id, creation_date, character, course, committee_head, status){
        this.id = id
        this.creation_date = creation_date
        this.character = character
        this.course = course
        this.committee_head = committee_head
        this.status = status
    }
}
